from flask import Flask, render_template, jsonify
import requests
import os

app = Flask(__name__)

# Configuración básica
RAWG_API_KEY = "30939597984a48708766775681966253" # API Key de ejemplo para RAWG

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/stats')
def stats():
    return render_template('stats.html')

# API Propia (Opción 2 del requerimiento)
@app.route('/api/games/featured')
def get_featured_games():
    # Simulamos datos de una API propia o procesamos datos de la externa
    try:
        response = requests.get(f'https://api.rawg.io/api/games?key={RAWG_API_KEY}&page_size=6', timeout=5)
        data = response.json()
        results = data.get('results', [])
        if not results:
            raise Exception("No data from API")
        return jsonify(results)
    except Exception as e:
        # Fallback data for demonstration
        fallback_games = [
            {
                "name": "The Witcher 3: Wild Hunt",
                "background_image": "https://media.rawg.io/media/games/618/618c49c64e06034f3ff5e4603e226991.jpg",
                "released": "2015-05-18",
                "rating": 4.66,
                "genres": [{"name": "RPG"}, {"name": "Action"}]
            },
            {
                "name": "Grand Theft Auto V",
                "background_image": "https://media.rawg.io/media/games/20a/20af502ed7494f30511015135a04c921.jpg",
                "released": "2013-09-17",
                "rating": 4.47,
                "genres": [{"name": "Action"}, {"name": "Adventure"}]
            },
            {
                "name": "Portal 2",
                "background_image": "https://media.rawg.io/media/games/328/3283617cb7d7505102fc44637fb5f451.jpg",
                "released": "2011-04-18",
                "rating": 4.61,
                "genres": [{"name": "Puzzle"}, {"name": "Platformer"}]
            }
        ]
        return jsonify(fallback_games)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
