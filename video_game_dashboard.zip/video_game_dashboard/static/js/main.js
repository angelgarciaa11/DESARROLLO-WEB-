document.addEventListener('DOMContentLoaded', function() {
    // Cargar juegos si estamos en la página de dashboard
    const gamesContainer = document.getElementById('games-container');
    if (gamesContainer) {
        fetchFeaturedGames();
    }

    // Inicializar gráficas si estamos en la página de estadísticas
    const genreChartCtx = document.getElementById('genreChart');
    if (genreChartCtx) {
        initGenreChart(genreChartCtx);
    }
});

async function fetchFeaturedGames() {
    const container = document.getElementById('games-container');
    const loading = document.getElementById('loading');

    try {
        const response = await fetch('/api/games/featured');
        const games = await response.json();

        loading.classList.add('d-none');
        container.classList.remove('d-none');

        games.forEach(game => {
            const card = `
                <div class="col-md-4">
                    <div class="card h-100 text-white">
                        <img src="${game.background_image}" class="card-img-top game-card-img" alt="${game.name}">
                        <div class="card-body">
                            <h5 class="card-title">${game.name}</h5>
                            <p class="card-text">
                                <span class="badge bg-info text-dark">${game.released}</span>
                                <span class="badge bg-warning text-dark">Rating: ${game.rating}</span>
                            </p>
                            <p class="small text-secondary">Géneros: ${game.genres.map(g => g.name).join(', ')}</p>
                        </div>
                    </div>
                </div>
            `;
            container.innerHTML += card;
        });
    } catch (error) {
        console.error('Error fetching games:', error);
        loading.innerHTML = '<p class="text-danger">Error al cargar los datos. Intente de nuevo.</p>';
    }
}

function initGenreChart(ctx) {
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Acción', 'Aventura', 'RPG', 'Shooter', 'Indie', 'Estrategia'],
            datasets: [{
                label: 'Popularidad por Género (%)',
                data: [85, 70, 65, 80, 55, 45],
                backgroundColor: [
                    'rgba(13, 110, 253, 0.7)',
                    'rgba(25, 135, 84, 0.7)',
                    'rgba(13, 202, 240, 0.7)',
                    'rgba(255, 193, 7, 0.7)',
                    'rgba(220, 53, 69, 0.7)',
                    'rgba(108, 117, 125, 0.7)'
                ],
                borderColor: 'rgba(255, 255, 255, 0.2)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    labels: { color: 'white' }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: 'white' }
                },
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.1)' },
                    ticks: { color: 'white' }
                }
            }
        }
    });
}
