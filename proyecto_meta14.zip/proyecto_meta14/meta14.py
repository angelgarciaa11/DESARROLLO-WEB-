from flask import Flask, render_template
import pandas as pd
import numpy as np

app = Flask(__name__)

@app.route("/")
def inicio():
    # Actividad complementaria: Agregue dos alumnos más con sus calificaciones
    nombres = ["Ana", "Luis", "Carlos", "Sofía", "Elena", "Pedro"]
    calificaciones = np.array([85, 90, 78, 92, 75, 88])

    # Crear el DataFrame
    df = pd.DataFrame({
        "nombre": nombres,
        "calificacion": calificaciones
    })

    # Actividad complementaria: Agregue una nueva columna de "estatus"
    # Si la calificación es mayor o igual a 80, "Aprobado", sino "Reprobado"
    df["estatus"] = np.where(df["calificacion"] >= 80, "Aprobado", "Reprobado")

    # Cálculos estadísticos
    promedio = np.mean(calificaciones)
    maximo = np.max(calificaciones)
    # Actividad complementaria: Calcule la calificación mínima
    minimo = np.min(calificaciones)

    # Convertir a diccionario para pasarlo a la plantilla
    datos = df.to_dict(orient="records")

    return render_template("meta14.html", datos=datos, promedio=promedio, maximo=maximo, minimo=minimo)

if __name__ == "__main__":
    # Usamos host='0.0.0.0' para que sea accesible en el entorno del sandbox
    app.run(debug=True, host='0.0.0.0', port=5000)
