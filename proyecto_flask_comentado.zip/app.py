# Importa los módulos necesarios de Flask
from flask import Flask, render_template, request, redirect, url_for

# Inicializa la aplicación Flask
app = Flask(__name__)

# Lista para almacenar los datos de los usuarios (simula una base de datos en memoria)
# Cada elemento de la lista será un diccionario con 'nombre' y 'correo'
usuarios_db = []

# Define la ruta principal de la aplicación ('/')
# Cuando un usuario accede a la raíz del sitio, se ejecuta esta función
@app.route(
    '/'
)
def index():
    """Ruta principal que renderiza el formulario y la tabla de usuarios."""
    # Renderiza la plantilla 'index.html'
    # Pasa la lista 'usuarios_db' a la plantilla para que pueda mostrar los datos
    return render_template('index.html', usuarios=usuarios_db)

# Define la ruta '/insertar' que solo acepta solicitudes POST
# Esta ruta se usa para procesar los datos enviados desde el formulario HTML
@app.route('/insertar', methods=['POST'])
def insertar():
    """Ruta para procesar los datos del formulario y guardarlos."""
    # Obtiene el valor del campo 'nombre' del formulario
    nombre = request.form.get('nombre')
    # Obtiene el valor del campo 'correo' del formulario
    correo = request.form.get('correo')
    
    # Verifica que tanto el nombre como el correo no estén vacíos
    if nombre and correo:
        # Si ambos campos tienen datos, crea un diccionario con la información del usuario
        usuarios_db.append({
            'nombre': nombre,
            'correo': correo
        })
    
    # Redirige al usuario de vuelta a la página principal ('/')
    # Esto evita que el formulario se reenvíe si el usuario recarga la página
    return redirect(url_for('index'))

# Bloque principal de ejecución del script
# Esto asegura que el servidor Flask solo se ejecute cuando el script se inicia directamente
if __name__ == '__main__':
    # Inicia el servidor de desarrollo de Flask
    # debug=True: Activa el modo de depuración (recarga automática, mensajes de error detallados)
    # port=5000: Especifica que la aplicación se ejecutará en el puerto 5000
    app.run(debug=True, port=5000)
