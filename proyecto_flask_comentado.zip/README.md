# Minimal Store - Flask App

Esta es una aplicación web profesional y minimalista construida con Flask.

## Estructura del Proyecto

- `app.py`: Lógica del negocio y rutas del servidor.
- `templates/`: Archivos HTML (base.html e index.html).
- `static/`: Recursos estáticos.
    - `css/`: Estilos minimalistas.
    - `js/`: Interactividad del lado del cliente.
    - `img/`: Carpeta para imágenes de productos.

## Cómo ejecutar

1. Asegúrate de tener Flask instalado: `pip install flask`
2. Ejecuta la aplicación: `python app.py`
3. Abre tu navegador en: `http://127.0.0.1:5000`

## Características
- Diseño minimalista y responsivo.
- Sistema de herencia de plantillas (Jinja2).
- Simulación de carrito de compras con JavaScript y API Flask.
- Estructura de carpetas profesional.
