// main.js: Este archivo contiene la lógica JavaScript para la interactividad del lado del cliente.

// 1. Validación del formulario: Asegura que el campo de nombre solo contenga letras.
// Se añade un 'event listener' al evento 'submit' del formulario con ID 'registroForm'.
document.getElementById('registroForm').addEventListener('submit', function(event) {
    // Obtiene la referencia al campo de entrada de nombre
    const nombreInput = document.getElementById('nombre');
    // Obtiene la referencia al elemento donde se mostrará el mensaje de error
    const errorNombre = document.getElementById('error-nombre');
    // Obtiene el valor del campo de nombre y elimina espacios en blanco al inicio y al final
    const nombreValue = nombreInput.value.trim();
    
    // Expresión regular para permitir solo letras (mayúsculas, minúsculas, con acentos) y espacios.
    // [a-zA-Z] cubre letras básicas, [áéíóúÁÉÍÓÚñÑ] cubre letras acentuadas y la 'ñ'.
    // \s+ permite uno o más espacios en blanco.
    const soloLetras = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/;
    
    // Comprueba si el valor del nombre NO cumple con la expresión regular (contiene caracteres no permitidos)
    if (!soloLetras.test(nombreValue)) {
        // Si no cumple, previene el envío del formulario al servidor.
        event.preventDefault();
        // Muestra un mensaje de error específico.
        errorNombre.textContent = "El nombre solo debe contener letras.";
        // Cambia el color del borde del campo de nombre a rojo para indicar un error.
        nombreInput.style.borderColor = "#ef4444"; // Usando la variable CSS --error
    } else {
        // Si el nombre es válido, limpia cualquier mensaje de error anterior.
        errorNombre.textContent = "";
        // Restaura el color del borde del campo de nombre a su estado normal.
        nombreInput.style.borderColor = "#e5e7eb"; // Usando la variable CSS --border-color
    }
});

// 2. Limpiar mensaje de error mientras el usuario escribe en el campo de nombre.
// Se añade un 'event listener' al evento 'input' (cada vez que el valor del campo cambia).
document.getElementById('nombre').addEventListener('input', function() {
    // Obtiene la referencia al elemento donde se muestra el mensaje de error.
    const errorNombre = document.getElementById('error-nombre');
    // Restaura el color del borde del campo de nombre.
    this.style.borderColor = "#e5e7eb"; // Usando la variable CSS --border-color
    // Limpia el mensaje de error.
    errorNombre.textContent = "";
});

// 3. Funcionalidad de los botones de acción en la parte inferior de la página.

// Botón "Ocultar Tarjetas": Alterna la visibilidad de las tarjetas de información.
document.querySelector('.btn-action:nth-child(1)').addEventListener('click', function() {
    // Selecciona todas las tarjetas con la clase 'card'.
    const cards = document.querySelectorAll('.card');
    // Itera sobre cada tarjeta.
    cards.forEach(card => {
        // Si la tarjeta está oculta (display === 'none'), la muestra ('block'); de lo contrario, la oculta.
        card.style.display = card.style.display === 'none' ? 'block' : 'none';
    });
});

// Botón "Cambiar Párrafos": Modifica el texto de los párrafos introductorios.
document.querySelector('.btn-action:nth-child(2)').addEventListener('click', function() {
    // Selecciona todos los párrafos dentro de la sección de introducción.
    const paragraphs = document.querySelectorAll('.intro-section p');
    // Cambia el texto del primer párrafo.
    paragraphs[0].textContent = "Este párrafo ha sido modificado por el usuario.";
    // Cambia el texto del segundo párrafo.
    paragraphs[1].textContent = "Este es el segundo párrafo modificado del sistema.";
});

// Botón "Agregar Tarjeta": Añade una nueva tarjeta de información dinámicamente.
document.querySelector('.btn-action:nth-child(3)').addEventListener('click', function() {
    // Crea un nuevo elemento div.
    const newCard = document.createElement('div');
    // Asigna la clase 'card' al nuevo div para aplicar los estilos CSS.
    newCard.className = 'card';
    // Establece el contenido HTML de la nueva tarjeta.
    newCard.innerHTML = '<h3>Nueva Tarjeta</h3><p>Esta tarjeta fue agregada dinámicamente.</p>';
    // Añade la nueva tarjeta al contenedor de tarjetas.
    document.querySelector('.cards-section').appendChild(newCard);
});

// Botón "Modificar Estilos Botones": Cambia temporalmente el color de fondo de los botones de acción.
document.querySelector('.btn-action:nth-child(4)').addEventListener('click', function() {
    // Selecciona todos los botones de acción.
    const buttons = document.querySelectorAll('.btn-action');
    // Itera sobre cada botón y cambia su color de fondo a verde.
    buttons.forEach(btn => {
        btn.style.backgroundColor = '#10b981'; // Usando la variable CSS --success
    });
    // Después de 2 segundos (2000 milisegundos), restaura el color original de los botones.
    setTimeout(() => {
        buttons.forEach(btn => {
            btn.style.backgroundColor = '#2563eb'; // Usando la variable CSS --accent-blue
        });
    }, 2000);
});

// Botón "Reiniciar": Recarga la página para restaurar su estado inicial.
document.querySelector('.btn-action:nth-child(5)').addEventListener('click', function() {
    // Recarga la página actual.
    location.reload();
});

// 4. Búsqueda en tiempo real en la tabla de usuarios.
// Se añade un 'event listener' al evento 'input' del campo de búsqueda en el encabezado.
document.querySelector('.input-search').addEventListener('input', function(e) {
    // Obtiene el término de búsqueda y lo convierte a minúsculas para una búsqueda insensible a mayúsculas/minúsculas.
    const searchTerm = e.target.value.toLowerCase();
    // Selecciona todas las filas del cuerpo de la tabla.
    const tableRows = document.querySelectorAll('table tbody tr');
    
    // Itera sobre cada fila de la tabla.
    tableRows.forEach(row => {
        // Obtiene el texto completo de la fila y lo convierte a minúsculas.
        const text = row.textContent.toLowerCase();
        // Si el texto de la fila incluye el término de búsqueda, muestra la fila; de lo contrario, la oculta.
        row.style.display = text.includes(searchTerm) ? 'table-row' : 'none';
    });
});
